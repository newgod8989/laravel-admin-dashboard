<p>
    Hello {{$name}} , We Just Wanna Notice You That Schedeler {{$schedele}} Has Finished Its Task
</p>