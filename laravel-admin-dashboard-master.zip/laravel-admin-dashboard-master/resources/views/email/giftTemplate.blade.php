<div>
    <h1>this is is my email for gifts</h1>
    {{$giftMessage}}
    {{$from}}
</div>