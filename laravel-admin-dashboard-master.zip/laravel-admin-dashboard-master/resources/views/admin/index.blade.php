@extends('layouts.app')

@section('content')
    <h2 class="text-center">Welcome To Your Application</h2>
@endsection
